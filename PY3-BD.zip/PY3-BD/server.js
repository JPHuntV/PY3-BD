const express = require('express')
const { graphqlHTTP } = require('express-graphql')
const {buildSchema} = require('graphql')

const bodyParser = require('body-Parser');
const path = require('path');
   // config for your database
const config = {
    user: 'JPHuntV',
    password: 'JpHv04102K',
    server: 'localhost', 
    database: 'AdventureWorks2017' 
}; 
const sql = require("mssql");

var app = express();


app.set('view engine', 'ejs');
app.set('views',path.join(__dirname,'views'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

app.get('/',function(req,res){
	res.render('index');
});

var pname="";
app.post('/Productos/search',function(req,res){
	pname = req.body.name;
	res.redirect('/Productos');
});

app.get('/Productos',function(req,res){
	sql.connect(config, function (err) {
        if (err) console.log(err);
        var request = new sql.Request();           
        request.query("exec ConsultaProduct N'"+pname+"'", 
        function (err, rows,fields) {
            if (err) console.log(err)
            	res.render('Productos',{
				prods:rows.recordset,
				test:null
			});           
        });
    });   
});
/*-----------------------------------------------------------------*/
var cname="";
app.post('/Clientes/search',function(req,res){
	cname = req.body.name;
	res.redirect('/Clientes');
});

app.get('/Clientes',function(req,res){
	sql.connect(config, function (err) {
        if (err) console.log(err);
        var request = new sql.Request();           
        request.query("exec ConsultaCustomer N'"+cname+"'", 
        function (err, rows,fields) {
            if (err) console.log(err)
            	res.render('Clientes',{
				clients:rows.recordset
			});           
        });
    });   
});
/*-------------------------------------------------------------------*/

/*-----------------------------------------------------------------*/
var venname="";
app.post('/Vendedores/search',function(req,res){
	venname = req.body.name;
	res.redirect('/Vendedores');
});

app.get('/Vendedores',function(req,res){
	sql.connect(config, function (err) {
        if (err) console.log(err);
        var request = new sql.Request();           
        request.query("exec ConsultaSale N'"+venname+"'", 
        function (err, rows,fields) {
            if (err) console.log(err)
            	res.render('Vendedores',{
				vendedores:rows.recordset
			});           
        });
    });   
});
/*-------------------------------------------------------------------*/
/*-----------------------------------------------------------------*/
var prname="";
app.post('/Proveedores/search',function(req,res){
	prname = req.body.name;
	res.redirect('/Proveedores');
});

app.get('/Proveedores',function(req,res){
	sql.connect(config, function (err) {
        if (err) console.log(err);
        var request = new sql.Request();           
        request.query("execute ConsultaProveedores N'"+prname+"'", 
        function (err, rows,fields) {
            if (err) console.log(err)
            	res.render('Proveedores',{
				provs:rows.recordset

			});           
        });
    });   
});
/*-------------------------------------------------------------------*/
/*-----------------------------------------------------------------*/
app.get('/Ventas',function(req,res){
	sql.connect(config, function (err) {
        if (err) console.log(err);
        var request = new sql.Request();           
        request.query("exec ConsultaSales N''", 
        function (err, rows,fields) {
            if (err) console.log(err)
            	res.render('Ventas',{
				sales:rows.recordset,
			});           
        });
    });   
});
/*-------------------------------------------------------------------*/
var server = app.listen(4000, function () {
    console.log('Server is running..');
});